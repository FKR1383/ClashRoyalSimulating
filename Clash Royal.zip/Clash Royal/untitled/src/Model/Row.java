package Model;

import Model.Cards.Card;
import Model.Cards.Spell.Spell;
import Model.Cards.Troop.Troop;

public class Row {
    private Card card;
    private User owner;
    private int health;
    private int time;

    public Row(Card card, User owner) {
        this.card = card;
        this.owner = owner;
        if (card instanceof Troop) {
            this.health = ((Troop) card).getHealth();
        } else {
            this.time = ((Spell)card).getTime();
        }
    }

    public void receiveDamage(int damage) {
        this.health -= damage;
    }

    public int getHealth() {
        return health;
    }

    public int getTime() {
        return time;
    }

    public void consume() {
        this.time--;
    }

    public void heal() {
        this.health += 1000;
        this.health = Math.max(((Troop)this.card).getHealth() , this.health);
    }

    public Card getCard() {
        return card;
    }

    public User getOwner() {
        return owner;
    }
}
