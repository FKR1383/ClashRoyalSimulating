package Model.Cards.Spell;

public class Fireball extends Spell{
    public Fireball() {
        this.name = "Fireball";
        this.price = 100;
        this.time = 1;
    }
}
