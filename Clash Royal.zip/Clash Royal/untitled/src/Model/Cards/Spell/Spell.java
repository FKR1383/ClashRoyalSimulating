package Model.Cards.Spell;

import Model.Cards.Card;

public class Spell extends Card {
    protected int time;

    public int getTime() {
        return time;
    }
}
