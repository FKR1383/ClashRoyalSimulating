package Model.Cards.Spell;

public class Heal extends Spell{
    public Heal() {
        this.name = "Heal";
        this.price = 150;
        this.time = 2;
    }
}
