package Model.Cards.Troop;

public class Barbarian extends Troop{
    public Barbarian() {
        this.name = "Barbarian";
        this.price = 100;
        this.health = 2000;
        this.damage = 900;
    }
}
