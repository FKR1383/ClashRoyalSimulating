package Model.Cards.Troop;

import Model.Cards.Card;

public class Troop extends Card {
    protected int health;

    public int getHealth() {
        return this.health;
    }

    public int getDamage() {
        return this.damage;
    }


    protected int damage;
}
