package Model.Cards.Troop;

public class IceWizard extends Troop{
    public IceWizard() {
        this.name = "Ice Wizard";
        this.price = 180;
        this.health = 3500;
        this.damage = 1500;
    }
}
