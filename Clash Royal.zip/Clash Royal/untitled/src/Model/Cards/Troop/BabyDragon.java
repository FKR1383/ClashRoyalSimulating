package Model.Cards.Troop;

public class BabyDragon extends Troop{
    public BabyDragon() {
        this.name = "Baby Dragon";
        this.price = 200;
        this.health = 3300;
        this.damage = 1200;
    }
}
