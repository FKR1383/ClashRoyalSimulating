package Model.Cards;

import Model.User;

public class Card{

    protected String name;
    protected int price;

    public int getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }
}
