package Model;

import Model.Cards.Card;
import Model.Cards.Spell.Fireball;
import Model.Cards.Troop.Barbarian;

import java.util.ArrayList;

public class User implements Comparable<User>{
    public long getExperience() {
        return experience;
    }

    public ArrayList<Card> getBattleDeck() {
        return battleDeck;
    }

    public long getGold() {
        return gold;
    }

    public String getPassword() {
        return password;
    }

    public int getLevel() {
        return level;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int compareTo(User user) {
         if (this.level > user.level) {
            return -1;
         }
         if (this.level < user.level) {
             return 1;
         }
         if (this.experience < user.experience) {
             return 1;
         }
         if (this.experience > user.experience) {
             return -1;
         }
         return this.username.compareTo(user.username);
    }

    private long gold , experience;
    private int level;
    private final static ArrayList<User> users = new ArrayList<User>();
    private final static ArrayList<String> usernames = new ArrayList<String>();

    private ArrayList<Card> battleDeck = new ArrayList<Card>();
    private ArrayList<Card> mycards = new ArrayList<Card>();

    public ArrayList<Card> getMycards() {
        return mycards;
    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public static ArrayList<String> getUsernames() {
        return usernames;
    }
    private String username , password;
    private int leftHitpoint , rightHitpoint , middleHitpoint;
    public void startingGame() {
        this.middleHitpoint = 3600*this.level;
        this.leftHitpoint = this.rightHitpoint = 2500*this.level;
    }

    public int getLeftHitpoint() {
        return leftHitpoint;
    }

    public int getRightHitpoint() {
        return rightHitpoint;
    }

    public int getMiddleHitpoint() {
        return middleHitpoint;
    }

    public void goldAchieved(int castleDestroyed) {
        this.gold += 25 * castleDestroyed;
    }

    public void experienceAchieved(long exp) {
        exp += this.experience;
        while (exp >= (long)this.level*this.level*160) {
            exp -= (long)this.level*this.level*160;
            this.level++;
        }
        this.experience = exp;
    }

    public void attack(String line , int damage) {
        switch (line) {
            case "left" : {
                this.leftHitpoint -= damage;
            } break;
            case "right" : {
                this.rightHitpoint -= damage;
            } break;
            case "middle" : {
                this.middleHitpoint -= damage;
            } break;
        }
    }

    public User(String username , String password) {
        this.username = username;
        this.password = password;
        this.gold = 100;
        this.level = 1;
        this.experience = 0;
        Fireball fb = new Fireball();
        Barbarian bar = new Barbarian();
        this.battleDeck.add(fb);
        this.battleDeck.add(bar);
        this.mycards.add(fb);
        this.mycards.add(bar);
        usernames.add(username);
        users.add(this);
    }

    public String getUsername() {
        return username;
    }

    public void purchase(int price) {
        this.gold -= price;
    }

    public void charge(int money) {
        this.gold += money;
    }

    public boolean correctPassword(String pass) {
        return pass.equals(this.password);
    }
}
