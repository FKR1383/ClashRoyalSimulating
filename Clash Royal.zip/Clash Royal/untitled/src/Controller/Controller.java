package Controller;

import Model.Cards.Card;
import Model.Cards.Spell.Fireball;
import Model.Cards.Spell.Heal;
import Model.Cards.Spell.Spell;
import Model.Cards.Troop.BabyDragon;
import Model.Cards.Troop.Barbarian;
import Model.Cards.Troop.IceWizard;
import Model.Cards.Troop.Troop;
import Model.Row;
import Model.User;
import View.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Controller {
    private String currentMenu = "Register/Login Menu";

    private static User currentUser;

    private Scanner scanner;

    private boolean running_program = true;
    private GameMenu gameMenu;

    public GameMenu getGameMenu() {
        return gameMenu;
    }

    private LoginMenu loginMenu;
    private MainMenu mainMenu;
    private ProfileMenu profileMenu;
    private ShopMenu shopMenu;

    public Controller(Scanner scanner) {
        this.scanner = scanner;
        gameMenu = new GameMenu(this);
        loginMenu = new LoginMenu(this);
        mainMenu = new MainMenu(this);
        profileMenu = new ProfileMenu(this);
        shopMenu = new ShopMenu(this);
    }

    public String getCurrentMenu() {
        return currentMenu;
    }

    public Scanner getScanner() {
        return scanner;
    }

    public void setRunning_program(boolean running_program) {
        this.running_program = running_program;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    public void setCurrentMenu(String menu) {
        this.currentMenu = menu;
    }

    public void run() {
        while (running_program) {
            switch (currentMenu) {
                case "Register/Login Menu": {
                    loginMenu.run();
                }
                break;
                case "Main Menu": {
                    mainMenu.run();
                }
                break;
                case "Shop Menu": {
                    shopMenu.run();
                }
                break;
                case "Game Menu": {
                    gameMenu.run();
                }
                break;
                case "Profile Menu": {
                    profileMenu.run();
                }
                break;
            }
        }
    }

    public String showMenu() {
        return this.getCurrentMenu();
    }

    public String back() {
        this.setCurrentMenu("Main Menu");
        return "Entered main menu!";
    }

    public String showHitpoints() {
        User opponent = gameMenu.nowTurn.equals(gameMenu.Host) ? gameMenu.Guest : gameMenu.Host;
        String result = "middle castle: " + (opponent.getMiddleHitpoint() > 0 ? opponent.getMiddleHitpoint() : -1) + "\nleft castle: " + (opponent.getLeftHitpoint() > 0 ? opponent.getLeftHitpoint() : -1) + "\nright castle: " + (opponent.getRightHitpoint() > 0 ? opponent.getRightHitpoint() : -1);
        return result;
    }

    public String showLine(Matcher matcher) {
        String direction = matcher.group("direction");
        if (!direction.equals("right") && !direction.equals("middle") && !direction.equals("left"))
            return "Incorrect line direction!";
        String result = direction + " line:";
        if (direction.equals("right")) {
            for (int i = 0; i != 15; i++) {
                for (Row row : gameMenu.getRightLine()[i]) {
                    result += "\nrow " + (i+1) + ": " + row.getCard().getName() + ": " + row.getOwner().getUsername();
                }
            }
        } else if (direction.equals("left")) {
            for (int i = 0; i != 15; i++) {
                for (Row row : gameMenu.getLeftLine()[i]) {
                    result += "\nrow " + (i+1) + ": " + row.getCard().getName() + ": " + row.getOwner().getUsername();
                }
            }
        } else {
            for (int i = 0; i != 15; i++) {
                for (Row row : gameMenu.getMiddleLine()[i]) {
                    result += "\nrow " + (i+1) + ": " + row.getCard().getName() + ": " + row.getOwner().getUsername();
                }
            }
        }
        return result;
    }

    public String numberOfCards() {
        String result = "You can play " + (gameMenu.didTurn() ? 0 : 1) + " cards more!";
        return result;
    }

    public String numberOfMoves() {
        String result = "You have " + gameMenu.movesLeft() + " moves left!";
        return result;
    }

    public String moveTroop(Matcher matcher) {
        String line = matcher.group("line");
        String rowString = matcher.group("row");
        String direction = matcher.group("direction");
        if (!line.equals("left") && !line.equals("middle") && !line.equals("right"))
            return "Incorrect line direction!";
        int row = Integer.parseInt(rowString);
        if (row < 1 || row > 15)
            return "Invalid row number!";
        if (!direction.equals("upward") && !direction.equals("downward"))
            return "you can only move troops upward or downward!";
        if (gameMenu.movesLeft() == 0)
            return "You are out of moves!";
        Row myrow = null;
        switch (line) {
            case "left" : {
                return isUserPlayedThisCardInThisCell (gameMenu.getLeftLine() , row , myrow , direction , line);
            }
            case "right" : {
                return isUserPlayedThisCardInThisCell (gameMenu.getRightLine() , row , myrow , direction , line);
            }
            case "middle" : {
                return isUserPlayedThisCardInThisCell (gameMenu.getMiddleLine() , row , myrow , direction , line);
            }
        }
        return "";
        // this state doesn't exist
    }

    private String isUserPlayedThisCardInThisCell (ArrayList <Row>[] line , int row , Row myrow , String direction , String lineName) {
        for (Row i : line[row-1]) {
            if (i.getOwner().equals(gameMenu.nowTurn) && i.getCard() instanceof Troop) {
                myrow = i;
                break;
            }
        }
        if (myrow == null)
            return "You don't have any troops in this place!";
        if ((row == 15 && direction.equals("upward")) || (row == 1 && direction.equals("downward")))
            return "Invalid move!";
        line[row-1].remove(myrow);
        if (direction.equals("downward")) {
            row--;
        } else {
            row++;
        }
        line[row-1].add(myrow);
        gameMenu.setMovesLeft(gameMenu.getMovesLeft()-1);
        return myrow.getCard().getName() + " moved successfully to row " + row + " in line " + lineName;
    }

    public String deployTroop(Matcher matcher) {
        String troop = matcher.group("troop");
        String line = matcher.group("line");
        String rowString = matcher.group("row");
        if (!troop.equals("Baby Dragon") && !troop.equals("Barbarian") && !troop.equals("Ice Wizard")) {
            return "Invalid troop name!";
        }
        Troop troopCard = null;
        for (Card card : gameMenu.nowTurn.getBattleDeck()) {
            if (card.getName().equals(troop)) {
                troopCard = (Troop)card;
            }
        }
        if (troopCard == null)
            return "You don't have " + troop + " card in your battle deck!";
        if (!line.equals("left") && !line.equals("middle") && !line.equals("right"))
            return "Incorrect line direction!";
        int row = Integer.parseInt(rowString);
        if (row < 1 || row > 15)
            return "Invalid row number!";
        if ((gameMenu.nowTurn.equals(gameMenu.Host) && row > 4) || (gameMenu.nowTurn.equals(gameMenu.Guest) && row < 12))
            return "Deploy your troops near your castles!";
        if (gameMenu.didTurn())
            return "You have deployed a troop or spell this turn!";
        Row nowRow = new Row(troopCard , gameMenu.nowTurn);
        switch (line) {
            case "left" : {
                gameMenu.getLeftLine()[row-1].add(nowRow);
            } break;
            case "right" : {
                gameMenu.getRightLine()[row-1].add(nowRow);
            } break;
            case "middle" : {
                gameMenu.getMiddleLine()[row-1].add(nowRow);
            } break;
        }
        gameMenu.setRunCard(true);
        return "You have deployed " + troop + " successfully!";
    }

    public String deployHeal(Matcher matcher) {
        String line = matcher.group("line");
        String rowString = matcher.group("row");
        if (!line.equals("left") && !line.equals("middle") && !line.equals("right"))
            return "Incorrect line direction!";
        Heal myheal = null;
        for (Card i : gameMenu.nowTurn.getBattleDeck()) {
            if (i.getName().equals("Heal")) {
                myheal = (Heal)i;
                break;
            }
        }
        if (myheal == null)
            return "You don't have Heal card in your battle deck!";
        int row = Integer.parseInt(rowString);
        if (row < 1 || row > 15)
            return "Invalid row number!";
        if (gameMenu.didTurn())
            return "You have deployed a troop or spell this turn!";
        Row myrow = new Row(myheal , gameMenu.nowTurn);
        switch (line) {
            case "left" : {
                gameMenu.getLeftLine()[row-1].add(myrow);
            } break;
            case "right" : {
                gameMenu.getRightLine()[row-1].add(myrow);
            } break;
            case "middle" : {
                gameMenu.getMiddleLine()[row-1].add(myrow);
            } break;
        }
        gameMenu.setRunCard(true);
        return "You have deployed Heal successfully!";
    }

    public String deployFireball(Matcher matcher) {
        String line = matcher.group("line");
        if (!line.equals("left") && !line.equals("middle") && !line.equals("right"))
            return "Incorrect line direction!";
        Fireball fireball = null;
        for (Card card : gameMenu.nowTurn.getBattleDeck()) {
            if (card.getName().equals("Fireball")) {
                fireball = (Fireball) card;
                break;
            }
        }
        if (fireball == null) {
            return "You don't have Fireball card in your battle deck!";
        }
        if (gameMenu.didTurn())
            return "You have deployed a troop or spell this turn!";
        User opponent  = gameMenu.nowTurn.equals(gameMenu.Host) ? gameMenu.Guest : gameMenu.Host;
        switch (line) {
            case "left" : {
                if (opponent.getLeftHitpoint() <= 0)
                    return "This castle is already destroyed!";
            } break;
            case "right" : {
                if (opponent.getRightHitpoint() <= 0)
                    return "This castle is already destroyed!";
            } break;
            case "middle" : {
                if  (opponent.getMiddleHitpoint() <= 0)
                    return "This castle is already destroyed!";
            } break;
        }
        opponent.attack(line , 1600);
        gameMenu.setRunCard(true);
        return "You have deployed Fireball successfully!";
    }

    public String nextTurn() {
        if (gameMenu.nowTurn.equals(gameMenu.Host)) {
            gameMenu.nowTurn = gameMenu.Guest;
            gameMenu.setRunCard(false);
            gameMenu.setMovesLeft(3);
            return "Player " + gameMenu.nowTurn.getUsername() + " is now playing!";
        }
        attackingTroopsAgainsTroops(gameMenu.getRightLine());
        attackingTroopsAgainsTroops(gameMenu.getMiddleLine());
        attackingTroopsAgainsTroops(gameMenu.getLeftLine());
        attackingCastlesAgainstTroops();
        return checkingGameIsEnd();
    }
    
    private void attackingTroopsAgainsTroops(ArrayList<Row> line[]) {
        for (int i = 0; i != 15; i++) {
            for (int j = 0; j != line[i].size(); j++) {
                switch (line[i].get(j).getCard().getName()) {
                    case "Fireball": {
                        line[i].get(j).consume();
                    }
                    break;
                    case "Heal": {
                        User owner = line[i].get(j).getOwner();
                        for (int k = 0; k != line[i].size(); k++) {
                            if (owner.equals(line[i].get(k).getOwner()) && line[i].get(k).getCard() instanceof Troop) {
                                line[i].get(k).heal();
                            }
                        }
                        line[i].get(j).consume();
                    }
                    break;
                    case "Barbarian": {
                        for (int k = j + 1; k != line[i].size(); k++) {
                            if (!line[i].get(k).getOwner().equals(line[i].get(j).getOwner()) && (line[i].get(k).getCard() instanceof IceWizard)) {
                                line[i].get(j).receiveDamage(((Troop) line[i].get(k).getCard()).getDamage() - ((Troop) line[i].get(j).getCard()).getDamage());
                            } else if (!line[i].get(k).getOwner().equals(line[i].get(j).getOwner()) && (line[i].get(k).getCard() instanceof BabyDragon)) {
                                line[i].get(j).receiveDamage(((Troop) line[i].get(k).getCard()).getDamage() - ((Troop) line[i].get(j).getCard()).getDamage());
                            }
                        }
                    }
                    break;
                    case "Ice Wizard": {
                        for (int k = j + 1; k != line[i].size(); k++) {
                            if (!line[i].get(k).getOwner().equals(line[i].get(j).getOwner()) && (line[i].get(k).getCard() instanceof Barbarian)) {
                                line[i].get(k).receiveDamage(((Troop) line[i].get(j).getCard()).getDamage() - ((Troop) line[i].get(k).getCard()).getDamage());
                            } else if (!line[i].get(k).getOwner().equals(line[i].get(j).getOwner()) && (line[i].get(k).getCard() instanceof BabyDragon)) {
                                line[i].get(k).receiveDamage(((Troop) line[i].get(j).getCard()).getDamage() - ((Troop) line[i].get(k).getCard()).getDamage());
                            }
                        }
                    }
                    break;
                    case "Baby Dragon": {
                        for (int k = j + 1; k != line[i].size(); k++) {
                            if (!line[i].get(k).getOwner().equals(line[i].get(j).getOwner()) && (line[i].get(k).getCard() instanceof Barbarian)) {
                                line[i].get(k).receiveDamage(((Troop) line[i].get(j).getCard()).getDamage() - ((Troop) line[i].get(k).getCard()).getDamage());
                            } else if (!line[i].get(k).getOwner().equals(line[i].get(j).getOwner()) && (line[i].get(k).getCard() instanceof IceWizard)) {
                                line[i].get(j).receiveDamage(((Troop) line[i].get(k).getCard()).getDamage() - ((Troop) line[i].get(j).getCard()).getDamage());
                            }
                        }
                    }
                    break;
                }
            }
        }
    }
    
    private void attackingCastlesAgainstTroops() {
        if (gameMenu.Host.getLeftHitpoint() > 0) {
            for (int i = 0; i != gameMenu.getLeftLine()[0].size(); i++) {
                if (gameMenu.getLeftLine()[0].get(i).getOwner().equals(gameMenu.Guest) && gameMenu.getLeftLine()[0].get(i).getCard() instanceof Troop) {
                    int damage = 500 * gameMenu.Host.getLevel();
                    gameMenu.getLeftLine()[0].get(i).receiveDamage(damage);
                    gameMenu.Host.attack("left", ((Troop) gameMenu.getLeftLine()[0].get(i).getCard()).getDamage());
                }
            }
        }
        if (gameMenu.Host.getRightHitpoint() > 0) {
            for (int i = 0; i != gameMenu.getRightLine()[0].size(); i++) {
                if (gameMenu.getRightLine()[0].get(i).getOwner().equals(gameMenu.Guest) && gameMenu.getRightLine()[0].get(i).getCard() instanceof Troop) {
                    int damage = 500 * gameMenu.Host.getLevel();
                    gameMenu.getRightLine()[0].get(i).receiveDamage(damage);
                    gameMenu.Host.attack("right", ((Troop) gameMenu.getRightLine()[0].get(i).getCard()).getDamage());
                }
            }
        }
        if (gameMenu.Host.getMiddleHitpoint() > 0) {
            for (int i = 0; i != gameMenu.getMiddleLine()[0].size(); i++) {
                if (gameMenu.getMiddleLine()[0].get(i).getOwner().equals(gameMenu.Guest) && gameMenu.getMiddleLine()[0].get(i).getCard() instanceof Troop) {
                    int damage = 500 * gameMenu.Host.getLevel();
                    gameMenu.getMiddleLine()[0].get(i).receiveDamage(damage);
                    gameMenu.Host.attack("middle", ((Troop) gameMenu.getMiddleLine()[0].get(i).getCard()).getDamage());
                }
            }
        }
        if (gameMenu.Guest.getLeftHitpoint() > 0) {
            for (int i = 0; i != gameMenu.getLeftLine()[14].size(); i++) {
                if (gameMenu.getLeftLine()[14].get(i).getOwner().equals(gameMenu.Host) && gameMenu.getLeftLine()[14].get(i).getCard() instanceof Troop) {
                    int damage = 500 * gameMenu.Guest.getLevel();
                    gameMenu.getLeftLine()[14].get(i).receiveDamage(damage);
                    gameMenu.Guest.attack("left", ((Troop) gameMenu.getLeftLine()[14].get(i).getCard()).getDamage());
                }
            }
        }
        if (gameMenu.Guest.getRightHitpoint() > 0) {
            for (int i = 0; i != gameMenu.getRightLine()[14].size(); i++) {
                if (gameMenu.getRightLine()[14].get(i).getOwner().equals(gameMenu.Host) && gameMenu.getRightLine()[14].get(i).getCard() instanceof Troop) {
                    int damage = 500 * gameMenu.Guest.getLevel();
                    gameMenu.getRightLine()[14].get(i).receiveDamage(damage);
                    gameMenu.Guest.attack("right", ((Troop) gameMenu.getRightLine()[14].get(i).getCard()).getDamage());
                }
            }
        }
        if (gameMenu.Guest.getMiddleHitpoint() > 0) {
            for (int i = 0; i != gameMenu.getMiddleLine()[14].size(); i++) {
                if (gameMenu.getMiddleLine()[14].get(i).getOwner().equals(gameMenu.Host) && gameMenu.getMiddleLine()[14].get(i).getCard() instanceof Troop) {
                    int damage = 500 * gameMenu.Guest.getLevel();
                    gameMenu.getMiddleLine()[14].get(i).receiveDamage(damage);
                    gameMenu.Guest.attack("middle", ((Troop) gameMenu.getMiddleLine()[14].get(i).getCard()).getDamage());
                }
            }
        }
        for (int i = 0; i != 15; i++) {
            Iterator<Row> it = gameMenu.getLeftLine()[i].iterator();
            while (it.hasNext()) {
                Row row = it.next();
                if (row.getCard() instanceof Troop && row.getHealth() <= 0)
                    it.remove();
                else if (row.getCard() instanceof Spell && row.getTime() == 0)
                    it.remove();
            }
            it = gameMenu.getRightLine()[i].iterator();
            while (it.hasNext()) {
                Row row = it.next();
                if (row.getCard() instanceof Troop && row.getHealth() <= 0)
                    it.remove();
                else if (row.getCard() instanceof Spell && row.getTime() == 0)
                    it.remove();
            }
            it = gameMenu.getMiddleLine()[i].iterator();
            while (it.hasNext()) {
                Row row = it.next();
                if (row.getCard() instanceof Troop && row.getHealth() <= 0)
                    it.remove();
                else if (row.getCard() instanceof Spell && row.getTime() == 0)
                    it.remove();
            }
        }
    }
    
    private String checkingGameIsEnd() {
        gameMenu.setTurns(gameMenu.getTurns()-1);
        long scoreHost = 0 , scoreGuest = 0;
        int destroyedCastleHost = 0 , destroyedCastleGuest = 0;
        destroyedCastleHost = (gameMenu.Host.getLeftHitpoint() <= 0 ? 1 : 0) + (gameMenu.Host.getMiddleHitpoint() <= 0 ? 1 : 0) + (gameMenu.Host.getRightHitpoint() <= 0 ? 1 : 0);
        destroyedCastleGuest = (gameMenu.Guest.getLeftHitpoint() <= 0 ? 1 : 0) + (gameMenu.Guest.getRightHitpoint() <= 0 ? 1 : 0) + (gameMenu.Guest.getMiddleHitpoint() <= 0 ? 1 : 0);
        scoreHost = Math.max(0 , gameMenu.Host.getLeftHitpoint()) + Math.max(0 , gameMenu.Host.getMiddleHitpoint()) + Math.max(0 , gameMenu.Host.getRightHitpoint());
        scoreGuest = Math.max(0 , gameMenu.Guest.getLeftHitpoint()) + Math.max(0 , gameMenu.Guest.getMiddleHitpoint()) + Math.max(0 , gameMenu.Guest.getRightHitpoint());
        if (gameMenu.getTurns() == 0 || scoreHost == 0 || scoreGuest == 0) {
            gameMenu.Host.goldAchieved(destroyedCastleGuest);
            gameMenu.Guest.goldAchieved(destroyedCastleHost);
            gameMenu.Host.experienceAchieved(scoreHost);
            gameMenu.Guest.experienceAchieved(scoreGuest);
            gameMenu.setGameEnded(true);
            if (scoreHost > scoreGuest) {
                return "Game has ended. Winner: " + gameMenu.Host.getUsername();
            } else if (scoreGuest > scoreHost) {
                return "Game has ended. Winner: " + gameMenu.Guest.getUsername();
            } else {
                return "Game has ended. Result: Tie";
            }
        }
        gameMenu.nowTurn = gameMenu.Host;
        gameMenu.setMovesLeft(3);
        gameMenu.setRunCard(false);
        return "Player " + gameMenu.nowTurn.getUsername() + " is now playing!";
    }

    private boolean validPassword(String test) {
        if (test.length() < 8 || test.length() > 20)
            return false;
        String regex = "\\s";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(test);
        if (matcher.find())
            return false;
        regex = "[a-z]";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(test);
        if (!matcher.find())
            return false;
        regex = "[A-Z]";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(test);
        if (!matcher.find())
            return false;
        regex = "[0-9]";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(test);
        if (!matcher.find())
            return false;
        if (test.charAt(0) >= '0' && test.charAt(0) <= '9')
            return false;
        regex = "[!@#$%^&*]";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(test);
        if (!matcher.find())
            return false;
        return true;
    }

    public String changePassword(Matcher matcher) {
        String oldpass = matcher.group("oldpass");
        String newpass = matcher.group("newpass");
        if (!Controller.getCurrentUser().correctPassword(oldpass))
            return "Incorrect password!";
        if (!validPassword(newpass))
            return "Incorrect format for new password!";
        Controller.getCurrentUser().setPassword(newpass);
        return "Password changed successfully!";
    }

    public String info() {
        User user = Controller.getCurrentUser();
        ArrayList <User> ranked = new ArrayList<User>(User.getUsers());
        Collections.sort(ranked);
        int rank = ranked.indexOf(user) + 1;
        String result = "username: " + user.getUsername() + "\npassword: " + user.getPassword() + "\nlevel: " + user.getLevel() + "\nexperience: " + user.getExperience() + "\ngold: " + user.getGold() + "\nrank: " + rank;
        return result;
    }

    public String removeFromBattle(Matcher matcher) {
        String cardName = matcher.group("cardname");
        User user = Controller.getCurrentUser();
        Card card = null;
        switch (cardName) {
            case "Fireball" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof Fireball) {
                        card = i;
                        break;
                    }
                }
            } break;
            case "Heal" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof Heal) {
                        card = i;
                        break;
                    }
                }
            } break;
            case "Barbarian" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof Barbarian) {
                        card = i;
                        break;
                    }
                }
            } break;
            case "Baby Dragon" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof BabyDragon) {
                        card = i;
                        break;
                    }
                }
            } break;
            case "Ice Wizard" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof IceWizard) {
                        card = i;
                        break;
                    }
                }
            } break;
            default: {
                return "Invalid card name!";
            }
        }
        if (card == null) {
            return "This card isn't in your battle deck!";
        }
        if (user.getBattleDeck().size() == 1)
            return "Invalid action: your battle deck will be empty!";
        user.getBattleDeck().remove(card);
        return "Card " + cardName + " removed successfully!";
    }

    public Card checkingIHaveThisCard(User user , String cardName) {
        switch (cardName) {
            case "Fireball" : {
                for (Card i : user.getMycards()) {
                    if (i instanceof Fireball) {
                        return i;
                    }
                }
            } break;
            case "Heal" : {
                for (Card i : user.getMycards()) {
                    if (i instanceof Heal) {
                        return i;

                    }
                }
            } break;
            case "Barbarian" : {
                for (Card i : user.getMycards()) {
                    if (i instanceof Barbarian) {
                        return i;
                    }
                }
            } break;
            case "Baby Dragon" : {
                for (Card i : user.getMycards()) {
                    if (i instanceof BabyDragon) {
                        return i;
                    }
                }
            } break;
            case "Ice Wizard" : {
                for (Card i : user.getMycards()) {
                    if (i instanceof IceWizard) {
                        return i;
                    }
                }
            } break;
        }
        return null;
    }

    public String addToDeck(Matcher matcher) {
        String cardName = matcher.group("cardname");
        User user = Controller.getCurrentUser();
        Card card = checkingIHaveThisCard(user , cardName);
        switch (cardName) {
            case "Fireball" : break;
            case "Heal" : break;
            case "Barbarian" : break;
            case "Baby Dragon" : break;
            case "Ice Wizard" : break;
            default: return "Invalid card name!";
        }
        if (card == null) {
            return "You don't have this card!";
        }
        Card addedCard = card;
        card = checkIfThisCardIsInMyBattleDeck(user , cardName);
        if (card != null) {
            return "This card is already in your battle deck!";
        }
        if (user.getBattleDeck().size() == 4)
            return "Invalid action: your battle deck is full!";
        user.getBattleDeck().add(addedCard);
        return "Card " + cardName + " added successfully!";
    }

    private Card checkIfThisCardIsInMyBattleDeck(User user , String cardName) {
        switch (cardName) {
            case "Fireball" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof Fireball) {
                        return i;
                    }
                }
            } break;
            case "Heal" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof Heal) {
                        return i;
                    }
                }
            } break;
            case "Barbarian" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof Barbarian) {
                        return i;
                    }
                }
            } break;
            case "Baby Dragon" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof BabyDragon) {
                        return i;
                    }
                }
            } break;
            case "Ice Wizard" : {
                for (Card i : user.getBattleDeck()) {
                    if (i instanceof IceWizard) {
                        return i;
                    }
                }
            } break;
        }
        return null;
    }

    public String showBattleDeck(Matcher matcher) {
        String result = "";
        User user = Controller.getCurrentUser();
        ArrayList<String> battleCards = new ArrayList<String>();
        for (Card card : user.getBattleDeck()) {
            battleCards.add(card.getName());
        }
        Collections.sort(battleCards);
        int index = 0;
        for (String i : battleCards) {
            if (index == 0) {
                result += i;
            } else {
                result += "\n" + i;
            }
            index++;
        }
        return result;
    }

    public String listOfUsers() {
        String result = "";
        int index = 0;
        for (User user : User.getUsers()) {
            if (index == 0) {
                result += "user " + (++index) + ": " + user.getUsername();
            } else {
                result += "\nuser " + (++index) + ": " + user.getUsername();
            }
        }
        return result;
    }

    public String scoreboard() {
        String result = "";
        ArrayList<User> ranked = new ArrayList<User>(User.getUsers());
        if (ranked.size() == 0)
            return result;
        Collections.sort(ranked);
        int index = 0;
        for (User user : ranked) {
            if (index == 0) {
                result += (++index) + "- username: " + user.getUsername() + " level: " + user.getLevel() + " experience: " + user.getExperience();
            } else {
                result += "\n" + (++index) + "- username: " + user.getUsername() + " level: " + user.getLevel() + " experience: " + user.getExperience();
            }
            if (index == 5)
                break;
        }
        return result;
    }

    public String logout() {
        this.setCurrentMenu("Register/Login Menu");
        return "User " + Controller.getCurrentUser().getUsername() + " logged out successfully!";
    }

    public String profileMenu() {
        this.setCurrentMenu("Profile Menu");
        return "Entered profile menu!";
    }

    public String shopMenu() {
        this.setCurrentMenu("Shop Menu");
        return "Entered shop menu!";
    }

    private boolean validCount(String test) {
        try {
            int count = Integer.parseInt(test);
            if (count < 5 || count > 30)
                return false;
            return true;
        } catch (final NumberFormatException e) {
            return false;
        }
    }

    public String startGame(Matcher matcher) {
        String username = matcher.group("username");
        String countString = matcher.group("count");
        if (!validCount(countString))
            return "Invalid turns count!";
        int count = Integer.parseInt(countString);
        if (!validUsername(username))
            return "Incorrect format for username!";
        if (!User.getUsernames().contains(username))
            return "Username doesn't exist!";
        this.setCurrentMenu("Game Menu");
        mainMenu.setStarting_game(true);
        this.getGameMenu().setGuest(User.getUsers().get(User.getUsernames().indexOf(username)));
        this.getGameMenu().setTurns(count);
        return "Battle started with user " + username;
    }

    private boolean validUsername(String test) {
        String regex = "[a-zA-Z]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(test);
        if (matcher.matches())
            return true;
        return false;
    }



    public String register(Matcher matcher) {
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (!validUsername(username))
            return "Incorrect format for username!";
        if (!validPassword(password))
            return "Incorrect format for password!";
        if (User.getUsernames().contains(username))
            return "Username already exists!";
        User user = new User(username , password);
        return "User " + username + " created successfully!";
    }

    public String login(Matcher matcher) {
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (!validUsername(username))
            return "Incorrect format for username!";
        if (!validPassword(password))
            return "Incorrect format for password!";
        if (!User.getUsernames().contains(username))
            return "Username doesn't exist!";
        User user = User.getUsers().get(User.getUsernames().indexOf(username));
        if (!user.correctPassword(password))
            return "Password is incorrect!";
        Controller.setCurrentUser(user);
        loginMenu.setSuccessfulLogin(true);
        return "User " + username + " logged in!";
    }

    private Card createNewCard(String cardName) {
        Card card = null;
        switch (cardName) {
            case "Fireball" : {
                card = new Fireball();
            } break;
            case "Heal" : {
                card = new Heal();
            } break;
            case "Barbarian" : {
                card = new Barbarian();
            } break;
            case "Baby Dragon" : {
                card = new BabyDragon();
            } break;
            case "Ice Wizard" : {
                card = new IceWizard();
            } break;
        }
        return card;
    }

    public String buyCard(Matcher matcher) {
        User user = Controller.getCurrentUser();
        String cardName = matcher.group("cardname");
        Card card = createNewCard(cardName);
        if (card == null)
            return "Invalid card name!";
        if (card.getPrice() > user.getGold()) {
            return "Not enough gold to buy " + cardName + "!";
        }
        for (Card i : user.getMycards()) {
            if (i.getName().equals(cardName)) {
                return "You have this card!";
            }
        }
        user.getMycards().add(card);
        user.purchase(card.getPrice());
        return "Card " + cardName + " bought successfully!";
    }

    private boolean invalidCardName(String cardName) {
        switch (cardName) {
            case "Fireball" :
            case "Heal" :
            case "Barbarian" :
            case "Baby Dragon" :
            case "Ice Wizard" : {
                return false;
            }
            default: {
                return true;
            }
        }
    }

    public String sellCard(Matcher matcher) {
        User user = Controller.getCurrentUser();
        String cardName = matcher.group("cardname");
        if (invalidCardName(cardName))
            return "Invalid card name!";
        Card card = checkingIHaveThisCard(user , cardName);
        if (card == null)
            return "You don't have this card!";
        if (user.getBattleDeck().contains(card))
            return "You cannot sell a card from your battle deck!";
        user.getMycards().remove(card);
        user.charge((int)(card.getPrice() * 0.8));
        return "Card " + cardName + " sold successfully!";
    }

}
