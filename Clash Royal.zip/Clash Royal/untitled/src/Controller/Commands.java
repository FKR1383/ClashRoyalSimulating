package Controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Commands {
    showMenuRegex("show current menu"),
    registerRegex("register username (?<username>.+) password (?<password>.+)"),
    loginRegex("login username (?<username>.+) password (?<password>.+)"),
    listOfUsersRegex("list of users"),
    scoreboardRegex("scoreboard"),
    profileMenuRegex("profile menu"),
    shopMenuRegex("shop menu"),
    startGameRegex("start game turns count (?<count>[\\d]+) username (?<username>.+)"),
    changePasswordRegex("change password old password (?<oldpass>.+) new password (?<newpass>.+)"),
    removeFromBattleRegex("remove from battle deck (?<cardname>.+)"),
    addToDeckRegex("add to battle deck (?<cardname>.+)"),
    showBattleDeckRegex("show battle deck"),
    buyCardRegex("buy card (?<cardname>.+)"),
    sellCardRegex("sell card (?<cardname>.+)"),
    showHitpointsRegex("show the hitpoints left of my opponent"),
    showLineRegex("show line info (?<direction>.+)"),
    numberOfCardsRegex("number of cards to play"),
    numberOfMovesRegex("number of moves left"),
    moveTroopRegex("move troop in line (?<line>.+) and row (?<row>[\\d]+) (?<direction>.+)"),
    deployTroopRegex("deploy troop (?<troop>.+) in line (?<line>.+) and row (?<row>[\\d]+)"),
    deployHealRegex("deploy spell Heal in line (?<line>.+) and row (?<row>[\\d]+)"),
    deployFireballRegex("deploy spell Fireball in line (?<line>.+)"),
    nextTurnRegex("next turn");

    private String regex;
    Commands(String regex) {
        this.regex = regex;
    }

    public static Matcher getMatcher(String input , Commands command) {
        Pattern pattern = Pattern.compile(command.regex);
        Matcher matcher = pattern.matcher(input);
        return matcher;
    }

}
