import Controller.Controller;

import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Controller mainControl = new Controller(scanner);
        mainControl.run();
    }
}
