package View;

import Controller.Commands;
import Controller.Controller;
import Model.Cards.Card;
import Model.Cards.Spell.Fireball;
import Model.Cards.Spell.Heal;
import Model.Cards.Spell.Spell;
import Model.Cards.Troop.BabyDragon;
import Model.Cards.Troop.Barbarian;
import Model.Cards.Troop.IceWizard;
import Model.Cards.Troop.Troop;
import Model.Row;
import Model.User;

import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Matcher;

public class GameMenu {
    private Controller controller;
    private Scanner scanner;
    private int turns , movesLeft;
    private boolean runCard;
    public static User Guest , Host , nowTurn;
    private boolean gameEnded = false;

    public void setMovesLeft(int movesLeft) {
        this.movesLeft = movesLeft;
    }

    public void setRunCard(boolean runCard) {
        this.runCard = runCard;
    }

    public void setGameEnded(boolean gameEnded) {
        this.gameEnded = gameEnded;
    }

    public void setLeftLine(ArrayList<Row>[] leftLine) {
        this.leftLine = leftLine;
    }

    public void setRightLine(ArrayList<Row>[] rightLine) {
        this.rightLine = rightLine;
    }

    public void setMiddleLine(ArrayList<Row>[] middleLine) {
        this.middleLine = middleLine;
    }

    public int getTurns() {
        return turns;
    }

    public int getMovesLeft() {
        return movesLeft;
    }

    public boolean isRunCard() {
        return runCard;
    }

    public boolean isGameEnded() {
        return gameEnded;
    }

    public ArrayList<Row>[] getLeftLine() {
        return leftLine;
    }

    public ArrayList<Row>[] getRightLine() {
        return rightLine;
    }

    public ArrayList<Row>[] getMiddleLine() {
        return middleLine;
    }

    private ArrayList<Row>[] leftLine = new ArrayList[15];
    private ArrayList<Row>[] rightLine = new ArrayList[15];
    private ArrayList<Row>[] middleLine = new ArrayList[15];


    public void setTurns(int turns) {
        this.turns = turns;
    }

    public void setGuest(User guest) {
        Guest = guest;
    }

    public void setBoard() {
        for (int i = 0; i != 15; i++) {
            leftLine[i] = new ArrayList<Row>();
            rightLine[i] = new ArrayList<Row>();
            middleLine[i] = new ArrayList<Row>();
        }
    }

    public GameMenu(Controller controller) {
        this.controller = controller;
        this.scanner = controller.getScanner();
    }

    public boolean didTurn() {
        return this.runCard;
    }

    public int movesLeft() {
        return this.movesLeft;
    }

    public void run() {
        Host = Controller.getCurrentUser();
        Host.startingGame();
        Guest.startingGame();
        nowTurn = Host;
        this.movesLeft = 3;
        this.runCard = false;
        this.setBoard();
        this.gameEnded = false;
        String command = scanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher showHitpointsMatcher = Commands.getMatcher(command , Commands.showHitpointsRegex);
        Matcher showLineMatcher = Commands.getMatcher(command , Commands.showLineRegex);
        Matcher numberOfCardsMatcher = Commands.getMatcher(command , Commands.numberOfCardsRegex);
        Matcher numberOfMovesMatcher = Commands.getMatcher(command , Commands.numberOfMovesRegex);
        Matcher moveTroopMatcher = Commands.getMatcher(command , Commands.moveTroopRegex);
        Matcher deployTroopMatcher = Commands.getMatcher(command , Commands.deployTroopRegex);
        Matcher deployHealMatcher = Commands.getMatcher(command , Commands.deployHealRegex);
        Matcher deployFireballMatcher = Commands.getMatcher(command , Commands.deployFireballRegex);
        Matcher nextTurnMatcher = Commands.getMatcher(command , Commands.nextTurnRegex);
        while (true) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (showHitpointsMatcher.matches()) {
                System.out.println(controller.showHitpoints());
            } else if (showLineMatcher.matches()) {
                System.out.println(controller.showLine(showLineMatcher));
            } else if (numberOfCardsMatcher.matches()) {
                System.out.println(controller.numberOfCards());
            } else if (numberOfMovesMatcher.matches()) {
                System.out.println(controller.numberOfMoves());
            } else if (moveTroopMatcher.matches()) {
                System.out.println(controller.moveTroop(moveTroopMatcher));
            } else if (deployTroopMatcher.matches()) {
                System.out.println(controller.deployTroop(deployTroopMatcher));
            } else if (deployHealMatcher.matches()) {
                System.out.println(controller.deployHeal(deployHealMatcher));
            } else if (deployFireballMatcher.matches()) {
                System.out.println(controller.deployFireball(deployFireballMatcher));
            } else if (nextTurnMatcher.matches()) {
                System.out.println(controller.nextTurn());
                if (gameEnded) {
                    gameEnded = false;
                    controller.setCurrentMenu("Main Menu");
                    break;
                }
            } else {
                System.out.println("Invalid command!");
            }
            command = scanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            showHitpointsMatcher = Commands.getMatcher(command , Commands.showHitpointsRegex);
            showLineMatcher = Commands.getMatcher(command , Commands.showLineRegex);
            numberOfCardsMatcher = Commands.getMatcher(command , Commands.numberOfCardsRegex);
            numberOfMovesMatcher = Commands.getMatcher(command , Commands.numberOfMovesRegex);
            moveTroopMatcher = Commands.getMatcher(command , Commands.moveTroopRegex);
            deployTroopMatcher = Commands.getMatcher(command , Commands.deployTroopRegex);
            deployHealMatcher = Commands.getMatcher(command , Commands.deployHealRegex);
            deployFireballMatcher = Commands.getMatcher(command , Commands.deployFireballRegex);
            nextTurnMatcher = Commands.getMatcher(command , Commands.nextTurnRegex);
        }
    }

}
