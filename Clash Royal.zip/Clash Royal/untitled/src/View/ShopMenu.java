package View;

import Controller.Controller;
import Controller.Commands;
import Model.Cards.Card;
import Model.Cards.Spell.Fireball;
import Model.Cards.Spell.Heal;
import Model.Cards.Troop.BabyDragon;
import Model.Cards.Troop.Barbarian;
import Model.Cards.Troop.IceWizard;
import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;

public class ShopMenu {
    private Controller controller;
    private Scanner scanner;
    public ShopMenu(Controller controller) {
        this.controller = controller;
        this.scanner = controller.getScanner();
    }
    public void run() {
        String command = scanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher buyCardMatcher = Commands.getMatcher(command , Commands.buyCardRegex);
        Matcher sellCardMatcher = Commands.getMatcher(command , Commands.sellCardRegex);
        while (true) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (command.equals("back")) {
                System.out.println(controller.back());
                break;
            } else if (buyCardMatcher.matches()) {
                System.out.println(controller.buyCard(buyCardMatcher));
            } else if (sellCardMatcher.matches()) {
                System.out.println(controller.sellCard(sellCardMatcher));
            }  else {
                System.out.println("Invalid command!");
            }
            command = scanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            buyCardMatcher = Commands.getMatcher(command , Commands.buyCardRegex);
            sellCardMatcher = Commands.getMatcher(command , Commands.sellCardRegex);
        }
    }

}