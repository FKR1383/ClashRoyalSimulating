package View;

import Controller.Controller;
import Controller.Commands;
import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginMenu {
    private Controller controller;
    private boolean successfulLogin = false;
    private Scanner scanner;

    public LoginMenu(Controller controller) {
        this.controller = controller;
        this.scanner = controller.getScanner();
    }

    public void setSuccessfulLogin(boolean successfulLogin) {
        this.successfulLogin = successfulLogin;
    }

    public boolean isSuccessfulLogin() {
        return successfulLogin;
    }

    public void run() {
        successfulLogin = false;
        String command = scanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher registerMatcher = Commands.getMatcher(command , Commands.registerRegex);
        Matcher loginMatcher = Commands.getMatcher(command , Commands.loginRegex);
        while (true) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (registerMatcher.matches()) {
                System.out.println(controller.register(registerMatcher));
            } else if (loginMatcher.matches()) {
                System.out.println(controller.login(loginMatcher));
                if (successfulLogin) {
                    controller.setCurrentMenu("Main Menu");
                    successfulLogin = false;
                    break;
                }
            } else if (command.equals("Exit")) {
                controller.setRunning_program(false);
                break;
            } else {
                System.out.println("Invalid command!");
            }
            command = scanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            registerMatcher = Commands.getMatcher(command , Commands.registerRegex);
            loginMatcher = Commands.getMatcher(command , Commands.loginRegex);
        }
    }


}
