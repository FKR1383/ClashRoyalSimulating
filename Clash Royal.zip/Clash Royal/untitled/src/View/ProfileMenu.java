package View;

import Controller.Controller;
import Controller.Commands;
import Model.Cards.Card;
import Model.Cards.Spell.Fireball;
import Model.Cards.Spell.Heal;
import Model.Cards.Troop.BabyDragon;
import Model.Cards.Troop.Barbarian;
import Model.Cards.Troop.IceWizard;
import Model.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProfileMenu {
    private Controller controller;
    private Scanner scanner;
    public ProfileMenu(Controller controller) {
        this.controller = controller;
        this.scanner = controller.getScanner();
    }

    public void run() {
        String command = scanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher changePasswordMatcher = Commands.getMatcher(command , Commands.changePasswordRegex);
        Matcher removeFromBattleMatcher = Commands.getMatcher(command , Commands.removeFromBattleRegex);
        Matcher addToDeckMatcher = Commands.getMatcher(command , Commands.addToDeckRegex);
        Matcher showBattleDeckMatcher = Commands.getMatcher(command , Commands.showBattleDeckRegex);
        while (true) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (command.equals("back")) {
                System.out.println(controller.back());
                break;
            } else if (changePasswordMatcher.matches()) {
                System.out.println(controller.changePassword(changePasswordMatcher));
            } else if (command.equals("Info")) {
                System.out.println(controller.info());
            } else if (removeFromBattleMatcher.matches()) {
                System.out.println(controller.removeFromBattle(removeFromBattleMatcher));
            } else if (addToDeckMatcher.matches()) {
                System.out.println(controller.addToDeck(addToDeckMatcher));
            } else if (showBattleDeckMatcher.matches()) {
                System.out.println(controller.showBattleDeck(showBattleDeckMatcher));
            } else {
                System.out.println("Invalid command!");
            }
            command = scanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            changePasswordMatcher = Commands.getMatcher(command , Commands.changePasswordRegex);
            removeFromBattleMatcher = Commands.getMatcher(command , Commands.removeFromBattleRegex);
            addToDeckMatcher = Commands.getMatcher(command , Commands.addToDeckRegex);
            showBattleDeckMatcher = Commands.getMatcher(command , Commands.showBattleDeckRegex);
        }
    }




}
