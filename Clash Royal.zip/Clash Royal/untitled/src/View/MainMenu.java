package View;

import Controller.Controller;
import Controller.Commands;
import Model.User;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainMenu {
    private Controller controller;
    private Scanner scanner;

    private boolean starting_game = false;

    public MainMenu(Controller controller) {
        this.controller = controller;
        this.scanner = controller.getScanner();
    }

    public boolean isStarting_game() {
        return starting_game;
    }

    public void setStarting_game(boolean starting_game) {
        this.starting_game = starting_game;
    }

    public void run() {
        starting_game = false;
        String command = scanner.nextLine();
        Matcher showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
        Matcher listOfUsersMatcher = Commands.getMatcher(command , Commands.listOfUsersRegex);
        Matcher scoreboardMatcher = Commands.getMatcher(command , Commands.scoreboardRegex);
        Matcher profileMenuMatcher = Commands.getMatcher(command , Commands.profileMenuRegex);
        Matcher shopMenuMatcher = Commands.getMatcher(command , Commands.shopMenuRegex);
        Matcher startGameMatcehr = Commands.getMatcher(command , Commands.startGameRegex);
        while (true) {
            if (showMenuMatcher.matches()) {
                System.out.println(controller.showMenu());
            } else if (listOfUsersMatcher.matches()) {
                String res = controller.listOfUsers();
                if (!res.equals("")) {
                    System.out.println(res);
                }
            } else if (scoreboardMatcher.matches()) {
                String res = controller.scoreboard();
                if (!res.equals(""))
                    System.out.println(res);
            } else if (command.equals("logout")) {
                System.out.println(controller.logout());
                break;
            } else if (profileMenuMatcher.matches()) {
                System.out.println(controller.profileMenu());
                break;
            } else if (shopMenuMatcher.matches()) {
                System.out.println(controller.shopMenu());
                break;
            } else if (startGameMatcehr.matches()) {
                System.out.println(controller.startGame(startGameMatcehr));
                if (starting_game) {
                    starting_game = false;
                    break;
                }
            } else {
                System.out.println("Invalid command!");
            }
            command = scanner.nextLine();
            showMenuMatcher = Commands.getMatcher(command , Commands.showMenuRegex);
            listOfUsersMatcher = Commands.getMatcher(command , Commands.listOfUsersRegex);
            scoreboardMatcher = Commands.getMatcher(command , Commands.scoreboardRegex);
            profileMenuMatcher = Commands.getMatcher(command , Commands.profileMenuRegex);
            shopMenuMatcher = Commands.getMatcher(command , Commands.shopMenuRegex);
            startGameMatcehr = Commands.getMatcher(command , Commands.startGameRegex);
        }
    }



}
